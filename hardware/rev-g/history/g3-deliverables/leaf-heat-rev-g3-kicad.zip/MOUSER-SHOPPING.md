# Rev G.3 Mouser basket — verified 14 September 2026

**The owner's Mouser Norway Chrome basket is complete: 28 product lines / 100 pieces, enough for two Rev G.3 boards without spares. Every requested quantity showed “Dispatches Now”; no duplicate products or backordered items remain. Nothing was ordered.**

| Cost | NOK |
| --- | ---: |
| Hand-fitted parts and antennas for two boards | **483.34** |
| Currently selected delivery estimate | 280.00 |
| Displayed basket subtotal | 763.34 |

Checkout taxes and the final delivery address/rate were not verified. These prices exclude the PCBs and factory assembly. The basket contains the 49 hand-fitted parts and one plug-in antenna per board; the assembler separately supplies and fits U1/U2/U4/U5/U6/L1. Cable, programmer, enclosure/fasteners and soldering supplies are excluded.

## Saved files

- [Shopping CSV with exact MPNs and PCB references](exports/MOUSER-TWO-BOARDS.csv)
- [Verified quantities, availability, prices and lifecycle flags](exports/MOUSER-BASKET-VERIFIED-2026-09-14.csv)
- [Mouser's original Excel export](exports/MOUSER-ORIGINAL-EXPORT-2026-09-14.xls)
- [Machine-readable comparison and verification record](exports/MOUSER-CART-VERIFICATION-2026-09-14.json)
- [Quick-order text for rebuilding an empty basket](exports/MOUSER-QUICK-ORDER-TWO-BOARDS.txt)

The live Chrome basket was checked line by line. Its downloaded Excel export was independently compared with both `MOUSER-TWO-BOARDS.csv` and the hand-part counts in `parts.json` plus `accessories.json`. All 28 exact Mouser SKUs, manufacturer MPNs and quantities agree, totaling 100 pieces and 483.34 NOK. Availability was verified separately in the live basket because the Excel export does not contain stock status. The old connector/CAN-chip customer labels now say Rev G.

The backordered untaped capacitor and the obsolete Omron buttons were removed. C15 is the specified **EEU-FR1J470H** taped straight-lead version, with two available. The replacement C&K buttons, pulse-resistant R21, precision R22/R23 and remaining protection parts are present. The quantities of reused capacitors/resistors include the new Rev G positions. No component or PCB change was needed during this cart update.

## Distributor lifecycle flags

Mouser's export marks **C1 / GRM32ER72A225KA35L as End of Life** and **D4 / PESD2CAN,215 as NRND (not recommended for new designs)**. Both required quantities are currently available and remain the exact parts already reviewed for this prototype. These flags concern future sourcing; they do not change the ordered electrical specifications. Revisit their availability and active alternatives before a later production run. Other lifecycle fields were blank, which is not evidence of an “Active” classification.

## If the basket is lost

For an empty basket, enter the 28 part numbers and quantities from the quick-order text or CSV. If a basket still exists, compare quantities before adding anything to avoid duplicates. Use cut tape/bulk quantities; no full reels or paid MouseReel service are needed. Stock and prices are a snapshot, so recheck when placing an order.

The current [JLCPCB quotation](quotations/2026-09-14/README.md) includes the six factory parts. The assembler’s exposed-pad DFM response remains outstanding. This completed electronics basket is not an assembly quote or an authorization to purchase.

Rev G.3 update: two Molex 1461530300 antennas (Mouser 538-146153-0300) added at 35.38 NOK each, 70.76 NOK total. All prior hand parts remain unchanged. U2 is factory-supplied by JLCPCB as ESP32-C3-WROOM-02U-N4/C2926676, so it is deliberately absent from this basket. The antenna needs no soldering or separate cable adapter. One small nylon cable tie per enclosure joins the existing list of mechanical supplies to obtain separately.

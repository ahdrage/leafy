# Rev G.1 manufacturing and partial assembly

Quote **five bare PCBs if required by the supplier's minimum, with only one or two assembled**. Quotation only; no order is authorized. Board: 100 × 100 mm, four copper layers, 1.6 mm nominal FR-4, 1 oz outer copper, green solder mask, white silk and lead-free finish. Retain the complete inner ground/power layers and all antenna keepouts. No copper, panel tabs or clamps under the ESP32 antenna overhang.

Use the Rev G Gerber/drill package and its matching factory BOM/CPL. **Fit exactly these six parts on top:**

| Ref | Exact manufacturer part |
| --- | --- |
| U1 | Texas Instruments LMR36510ADDAR |
| U2 | Espressif ESP32-C3-WROOM-02-N4 |
| U4 | STMicroelectronics USBLC6-2SC6 |
| U5 | Texas Instruments TPS3760A012DYYR — JLCPCB C5218894, Catalog grade, approved Rev G.1 substitution |
| U6 | Texas Instruments TMUX1511PWR |
| L1 | Bourns SRN6045TA-220M |

No substitutions or additional placements without engineering review. U5 must be the non-latching undervoltage variant. The factory supplies these components; they are excluded from the customer's Mouser hand-parts basket. JLCPCB catalog IDs remain blank until the exact manufacturer parts are matched; do not accept automatic substitutes. Quote sourcing/MOQ/attrition separately.

The top paste layer contains apertures for these six parts only. The other 49 purchased components are customer-fitted; TP1–TP7 and H1–H4 are bare PCB features. Do not populate them. Do not regenerate a stencil that includes the hand-fitted parts. The partially assembled board is not a functional circuit and must not be powered or programmed before hand assembly.

**DFM response required before order:** U1/U2 exposed pads contain unfilled plated thermal holes. Confirm stencil thickness, aperture coverage, reflow process, how solder loss through these holes is controlled, and inspection of exposed-pad attachment. Confirm whether the supplied design can be assembled reliably as drawn. If filled/capped vias or another change is required, identify the required fabrication change and cost before proceeding. Tenting is not via filling. Please provide inspection images/results for the fitted parts; no finished-board functional test is implied.

Placement origin: lower-left board corner, KiCad (0,100 mm); X right and Y up in CSV. Rotations are KiCad angles. Review pin 1, the ESP32 antenna orientation and all six placements against `assembly-map.png` and `factory-paste.png`. Keep the connector overhang and printed-case clearances intact. Quote setup, PCB batch, stencil, six parts, soldering and inspection separately. Existing Rev F quotes are obsolete for this revision.

Rev G.1 is a U5 BOM revision on unchanged Rev G copper. Use the current TPS3760A012DYYR / C5218894; see [the change record](U5-G1-CHANGE.md). Gerber copper/mask/paste/silkscreen files are byte-identical to Rev G; drill geometry is identical. Only the BOM, identity metadata and supporting documents change.

## JLCPCB catalogue orientation

Use `exports/CPL-FACTORY-JLCPCB.csv` for JLCPCB: final rotations U1/U5/U6 = 270°, U4 = 0°, U2/L1 = 0°. These already include the catalogue zero-angle correction; do not add it again. `placements-FACTORY.csv` and `CPL-NATIVE-REFERENCE-ONLY.csv` are native KiCad references for other assemblers. Verify physical pin 1 using `FACTORY-PIN1-REFERENCE.csv` and the supplied drawings. All centres remain unchanged. The live JLCPCB preview was checked, but a final manufacturer placement approval is still required.

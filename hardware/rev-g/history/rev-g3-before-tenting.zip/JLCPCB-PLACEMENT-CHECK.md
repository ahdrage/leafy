# JLCPCB Rev G.3 placement check — 14 September 2026

The current quote is `leaf-heat-rev-g3-gerbers`, PCB file number `ecc805476ca84796830c2f4ab2ec16b7`. The live viewer loaded the G.3 silkscreen and the external-antenna module. All six factory parts were inspected individually at enlarged scale. No translation or additional rotation was necessary after importing the current CPL. The viewer was checked again when restoring the same files as cart entry Y9 after cancelling a temporary unpaid Y6 checkout record; all six placements remained aligned. See [the current cart backup](quotations/2026-09-14/cart-recheck-2026-09-14.json).

| Part | JLCPCB code | Native KiCad angle | JLC angle | Live preview check |
| --- | --- | ---: | ---: | --- |
| L1 | C2044314 | 0° | 0° | Centred, both terminals aligned, nonpolar |
| U1 | C1858393 | 0° | 270° | Eight leads aligned; pin one upper-left |
| U2 | C2926676 | 0° | 0° | External-antenna 02U model; all eighteen outer castellations aligned, pin one upper-left, socket upper-right |
| U4 | C7519 | 90° | 0° | Six leads aligned; pin one lower-left |
| U5 | C5218894 | 0° | 270° | Fourteen leads aligned; pin one upper-left |
| U6 | C2866750 | 0° | 270° | Fourteen leads aligned; pin one upper-left |

The module origin remains KiCad (73,8) mm, exported (73,92) mm with a lower-left origin. Its pin-one pad is exported (64.25,98) mm. Its different body height does not require changing this footprint anchor: the live JLCPCB model is aligned at the supplied coordinates. U2's central ground pad/paste matches the native data, but it is concealed under the 3D body; the preview is not an inspection of the solder joint.

`CPL-FACTORY-JLCPCB.csv` already includes the catalogue angle corrections. Do not rotate it again. `CPL-NATIVE-REFERENCE-ONLY.csv` and `placements-FACTORY.csv` preserve native angles; use `FACTORY-PIN1-REFERENCE.csv` to check physical pin one. All centres and paste apertures remain unchanged from G.2.

The quotation has manual production-file and component-placement approval requested, with automatic confirmation disabled in both dialogs. The assembly remark identifies the exact 02U module, excludes ANT1 from factory placement, forbids powering the incomplete assembly and requests exposed-pad DFM for U1/U2. Final assembler DFM and production placement approval remain outstanding. No hardware or vehicle test has been performed.

The old G.1 quote remains historical; its Gerbers and U2 component are obsolete. Use only the G.3 cart entry and current files. The complete old G.2 design and packages are preserved under `history`.

# Leaf heat — Rev G

Rev G adds input damping and independent low-battery shutdown to the 100 × 100 mm, four-layer Wi-Fi/CAN board. It retains the hand-solder layout, Nissan DB9 cable interface and UART programming connector. **Rev F is preserved. This is a checked prototype design, not a vehicle-qualified product.**

- [Open in KiCad](leaf-heat-v7.kicad_pro), [schematic PDF](exports/schematic.pdf), [assembly image](exports/assembly-map.png)
- [Design review and remaining tests](DESIGN-REVIEW.md)
- [Factory instructions](MANUFACTURING-NOTES.md), [hand assembly](HAND-ASSEMBLY.md)
- [Exact hand-parts list for two boards](exports/MOUSER-HAND-TWO-BOARDS.csv), [verified basket and prices](MOUSER-SHOPPING.md)
- [Vehicle wiring](VEHICLE-WIRING.md), [firmware and programming](../../firmware/leaf-heat/README.md)
- [Updated Blender enclosure](../../enclosure/rev-g-v1/README.md)
- [Manufacturing/review packages](deliverables/README.md)

The factory now fits **U1, U2, U4, U5, U6 and L1**. U5 is the battery supervisor and U6 isolates the battery measurement when the 3.3 V supply is off; both have fine-pitch pins. You fit **49 other components per board**, using 27 different hand-parts products. The two-board shopping list contains 98 pieces, without spares. U3 and D4 still require careful hand soldering.

The important changes are:

- C15/R21 add a 47 µF / 63 V electrolytic capacitor with a separate 1 Ω damping resistor. The resistor is in the capacitor branch, not the board's main power path.
- U5 controls the regulator's enable pin independently of firmware. Nominal thresholds are approximately **11.67 V off / 12.68 V restart, measured after D1**, with nominal 1.27 s / 12.7 s delays. Actual thresholds and delays require measurement; see the review.
- U6 prevents the live battery divider from feeding an unpowered ESP32 ADC. The powered ADC conversion factor changes to **32.2766**.
- Regulator VCC and feedback routes shorten from 8.50 / 8.75 mm to 3.57 / 4.03 mm. Ground planes and antenna clearance are retained.
- The through-hole buttons change to C&K PTS645SL43-2 LFS, matching the contact geometry and 4.3 mm height.

The firmware is built around continuous Wi-Fi availability: station mode, modem sleep, automatic light sleep and unlimited reconnect attempts with a maximum 30-second retry interval. There is no intentional deep sleep or periodic offline schedule. Use the same non-isolated LAN and reserve the board's IP address in the router. **Low-battery cutoff necessarily makes the board unreachable until charging restores its supply.** Router outages, signal loss and firmware/hardware faults can also interrupt access.

Fresh ERC and DRC report zero errors, unconnected items or schematic mismatches under the configured rules. An independent script checks all 55 purchased components, critical pin connections, assembly ownership, unchanged cable/mount geometry and Rev F hashes. The firmware compiles, and its command/retry logic passes host tests. These checks do not establish real supply ripple, current consumption, RF performance or actual heater behavior.

The Mouser cart is complete and matches the BOM: 412.58 NOK for the hand parts for two boards, before delivery and any checkout taxes. See the shopping notes for the available C1/D4 lifecycle flags. Before ordering, resolve the assembler's U1/U2 exposed-pad process and recheck stock/prices. Before vehicle use, complete the bench plan, confirm the battery label and cable/TCU arrangement. The user's remembered TCU disconnection supports the 2013–2015 profile but is not a continuity test.

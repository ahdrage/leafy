from pathlib import Path
import hashlib,json,zipfile,datetime
H=Path(__file__).resolve().parent;E=H/'exports';D=H/'deliverables';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((E/'independent-audit.json').read_text());m=json.loads((E/'manufacturing-audit.json').read_text())
assert a['board_sha256']==m['board_sha256']==sha(H/'leaf-heat-v7.kicad_pcb')
assert a['schematic_sha256']==sha(H/'leaf-heat-v7.kicad_sch')
(D/'README.md').write_text((H/'deliverables-README.tmp').read_text())
def make(name,files,base):
 files=sorted(set(p for p in files if p.is_file()));manifest={'revision':'G','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pcb_sha256':a['board_sha256'],'schematic_sha256':a['schematic_sha256'],'files':{str(p.relative_to(base)):sha(p) for p in files}}
 with zipfile.ZipFile(D/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,p.relative_to(base))
  z.writestr('PACKAGE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(D/name) as z:
  assert z.testzip() is None
  for n,h in manifest['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
fabrication=list((E/'fabrication').glob('*'))
make('leaf-heat-rev-g-gerbers.zip',fabrication,E/'fabrication')
factory=fabrication+[H/'MANUFACTURING-NOTES.md',E/'BOM-FACTORY-PCBWay.csv',E/'BOM-FACTORY-JLCPCB.csv',E/'placements-FACTORY.csv',E/'CPL-FACTORY-JLCPCB.csv',E/'assembly-map.png',E/'factory-paste.png',E/'schematic.pdf',E/'manufacturing-audit.json']
make('leaf-heat-rev-g-factory-assembly.zip',factory,H)
hand=[H/x for x in ['HAND-ASSEMBLY.md','VEHICLE-WIRING.md','MOUSER-SHOPPING.md','DESIGN-REVIEW.md']]+[E/x for x in ['BOM-HAND.csv','MOUSER-HAND-TWO-BOARDS.csv','MOUSER-QUICK-ORDER-TWO-BOARDS.txt','MOUSER-CART-CHANGES.csv','MOUSER-BASKET-VERIFIED-2026-09-13.csv','MOUSER-ORIGINAL-EXPORT-2026-09-13.xls','MOUSER-CART-VERIFICATION-2026-09-13.json','assembly-map.png','back-legend.png','schematic.pdf']]
make('leaf-heat-rev-g-hand-assembly.zip',hand,H)
native=[H/x for x in ['leaf-heat-v7.kicad_pcb','leaf-heat-v7.kicad_sch','leaf-heat-v7.kicad_pro','leaf-heat-v7.kicad_dru','Leaf.kicad_sym','sym-lib-table','fp-lib-table','parts.json','testpoints.json']]+list((H/'Leaf.pretty').glob('*.kicad_mod'))+list(H.glob('*.md'))+[E/x for x in ['independent-audit.json','manufacturing-audit.json','protection-calculations.json','erc.json','drc-final.json','BOM-FULL-REFERENCE-ONLY.csv']]
make('leaf-heat-rev-g-kicad.zip',native,H)
images=[E/x for x in ['top.png','ground.png','power.png','bottom.png','placement.png','factory-paste.png','assembly-map.png','back-legend.png','schematic.png','schematic.pdf']]
make('leaf-heat-rev-g-review-images.zip',images,E)
(D/'manifest.json').write_text(json.dumps({'pcb_sha256':a['board_sha256'],'schematic_sha256':a['schematic_sha256'],'packages':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in D.glob('*.zip')}},indent=2)+'\n')
print('Five matched packages created and zip contents verified.')

# Rev G deliverables

These packages belong together. **Quotation/review only until assembler DFM is confirmed.** Earlier Rev F quotations/BOMs do not cover Rev G.

- `leaf-heat-rev-g-gerbers.zip`: four-layer fabrication data and drill files.
- `leaf-heat-rev-g-factory-assembly.zip`: Gerbers, exact six-part factory BOM, placements, paste drawing and manufacturing instructions. Factory fits U1/U2/U4/U5/U6/L1 only.
- `leaf-heat-rev-g-hand-assembly.zip`: 49 hand parts per board, Mouser list for two boards, diagrams and hand/wiring instructions. The browser cart is verified; the package includes its original export, prices and comparison report.
- `leaf-heat-rev-g-kicad.zip`: native editable project, local libraries, BOM source and review reports.
- `leaf-heat-rev-g-review-images.zip`: schematic, top/bottom/inner layers, paste, assembly and back-side values.

The standalone firmware source and Blender/print package are linked from the Rev G README. No purchase or powered hardware validation is implied by exporting these files. SHA-256 manifests record the native board, schematic and packaged files.

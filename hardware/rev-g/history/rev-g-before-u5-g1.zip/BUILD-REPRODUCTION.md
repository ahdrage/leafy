# Rev G sources and reproducibility

Use the supplied native KiCad files and matched ZIPs for this checked revision. They are the authoritative reviewed artifacts; scripts are engineering generators, not a one-click production release system.

Generation sequence:

1. `build_rev_g.py` copies the preserved Rev F source, adds the new circuitry and critical regulator routes.
2. `route_rev_g.py` adds plane fanouts. `prepare_router.py` prepares the external-router DSN. The local Freerouting session is in `exports/leaf-heat-v7.ses`; it was imported using KiCad's native `ImportSpecctraSES` function.
3. `finish_rev_g.py` completes the fine-pitch escapes. `finalize_values.py` applies the final precision resistors, 10 µF delay caps, taped C15 ordering part, and all 27 hand-parts rows on the back. Do not use the builder's intermediate values as the BOM.
4. Run native schematic netlist export/ERC and PCB DRC with copper refill, save-board and schematic parity. Run `audit_rev_g.py`, `analyze_protection.py` and `export_rev_g.py` with the KiCad Python runtime. The audit reads both native revisions; it does not modify them.
5. `make_shopping_list.py` regenerates the final target quantities. Live basket availability/prices are a separate verification step and cannot be inferred from this script.
6. `package_rev_g.py` checks native hashes against the audit and packages the final Gerbers, BOMs, placements and review files. If any native file changes, regenerate all dependent exports, audits and packages.

Python runtime: `tools/KiCAD-MCP-Server/venv/bin/python3`, with KiCad 10.0.6. CLI: `/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli`. Set `FONTCONFIG_FILE` to the repository's `hardware/fontconfig.xml`. The Freerouting jar/JRE are under `tools/freerouting`; router results may vary by runtime/version and must receive a fresh native DRC after import.

The enclosure has separate geometry/hash checks described in its README. Changing the PCB requires refreshing its GLB reference and native geometry hash before rebuilding the Blender model. Firmware has its own pinned build configuration and host tests.

Historical intermediates and logs under `exports/` are retained for investigation. Only the five ZIPs listed in `deliverables/README.md` are the current board handoff packages. No assembler DFM approval or physical qualification is implied by reproducibility or matching hashes.

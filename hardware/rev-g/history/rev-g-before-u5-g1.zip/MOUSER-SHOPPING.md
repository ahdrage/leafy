# Rev G Mouser basket — verified 13 September 2026

**The owner's Mouser Norway Chrome basket is complete: 27 product lines / 98 pieces, enough for two Rev G boards without spares. Every requested quantity showed “Dispatches Now”; no duplicate products or backordered items remain. Nothing was ordered.**

| Cost | NOK |
| --- | ---: |
| Hand-fitted components for two boards | **412.58** |
| Currently selected delivery estimate | 280.00 |
| Displayed basket subtotal | 692.58 |

Checkout taxes and the final delivery address/rate were not verified. These prices exclude the PCBs and factory assembly. The basket contains the 49 hand-fitted parts per board; the assembler separately supplies and fits U1/U2/U4/U5/U6/L1. Cable, programmer, enclosure/fasteners and soldering supplies are excluded.

## Saved files

- [Shopping CSV with exact MPNs and PCB references](exports/MOUSER-HAND-TWO-BOARDS.csv)
- [Verified quantities, availability, prices and lifecycle flags](exports/MOUSER-BASKET-VERIFIED-2026-09-13.csv)
- [Mouser's original Excel export](exports/MOUSER-ORIGINAL-EXPORT-2026-09-13.xls)
- [Machine-readable comparison and verification record](exports/MOUSER-CART-VERIFICATION-2026-09-13.json)
- [Quick-order text for rebuilding an empty basket](exports/MOUSER-QUICK-ORDER-TWO-BOARDS.txt)

The live Chrome basket was checked line by line. Its downloaded Excel export was independently compared with both `MOUSER-HAND-TWO-BOARDS.csv` and the hand-part counts in `parts.json`. All 27 exact Mouser SKUs, manufacturer MPNs and quantities agree, totaling 98 pieces and 412.58 NOK. Availability was verified separately in the live basket because the Excel export does not contain stock status. The old connector/CAN-chip customer labels now say Rev G.

The backordered untaped capacitor and the obsolete Omron buttons were removed. C15 is the specified **EEU-FR1J470H** taped straight-lead version, with two available. The replacement C&K buttons, pulse-resistant R21, precision R22/R23 and remaining protection parts are present. The quantities of reused capacitors/resistors include the new Rev G positions. No component or PCB change was needed during this cart update.

## Distributor lifecycle flags

Mouser's export marks **C1 / GRM32ER72A225KA35L as End of Life** and **D4 / PESD2CAN,215 as NRND (not recommended for new designs)**. Both required quantities are currently available and remain the exact parts already reviewed for this prototype. These flags concern future sourcing; they do not change the ordered electrical specifications. Revisit their availability and active alternatives before a later production run. Other lifecycle fields were blank, which is not evidence of an “Active” classification.

## If the basket is lost

For an empty basket, enter the 27 part numbers and quantities from the quick-order text or CSV. If a basket still exists, compare quantities before adding anything to avoid duplicates. Use cut tape/bulk quantities; no full reels or paid MouseReel service are needed. Stock and prices are a snapshot, so recheck when placing an order.

The six-part factory BOM still needs a fresh manufacturing quotation and the assembler's exposed-pad DFM response. This completed electronics basket is not an assembly quote or an authorization to purchase.

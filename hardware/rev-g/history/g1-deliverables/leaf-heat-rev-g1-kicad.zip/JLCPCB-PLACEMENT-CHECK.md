# JLCPCB Rev G.1 placement check — 13 September 2026

The user approved correcting the catalogue preview orientations. Every factory part was checked against its native PCB pads. The corrected preview was saved to the draft `leaf-heat-rev-g1-U5-stocked` at 21:46 Oslo time. The corrected CPL was subsequently re-uploaded and all six placements rechecked before saving at 22:01. The finished quote was saved to the cart at 22:02.

| Part | JLCPCB code | Native KiCad angle | JLC angle | Check |
| --- | --- | ---: | ---: | --- |
| L1 | C2044314 | 0° | 0° | Nonpolar, centre and terminal alignment |
| U1 | C1858393 | 0° | 270° | Eight leads aligned; pin-one marker upper-left |
| U2 | C2934560 | 0° | 0° | Castellations aligned; antenna overhang outside board |
| U4 | C7519 | 90° | 0° | Six leads aligned; pin-one marker lower-left |
| U5 | C5218894 | 0° | 270° | Fourteen leads aligned; pin-one marker upper-left |
| U6 | C2866750 | 0° | 270° | Fourteen leads aligned; pin-one marker upper-left |

Directions are the top view with board text upright. `exports/FACTORY-PIN1-REFERENCE.csv` gives numeric centre and pad-one positions with a lower-left origin, X right and Y up. The checks did not move any component or alter PCB geometry.

The `CPL-FACTORY-JLCPCB.csv` exporter applies a +270° catalogue offset to U1/U4/U5/U6 only, modulo 360°. `CPL-NATIVE-REFERENCE-ONLY.csv` preserves the original raw coordinates/angles for comparison. The separate `placements-FACTORY.csv` remains the KiCad native placement output. These differing angle conventions must not be mixed or corrected twice.

JLCPCB's catalogue models are a preview, not a physical assembly inspection. Keep customer placement approval enabled and have the assembler confirm exposed-pad assembly and pin-one alignment before manufacturing approval. No prototype power or vehicle test has been performed by this review.

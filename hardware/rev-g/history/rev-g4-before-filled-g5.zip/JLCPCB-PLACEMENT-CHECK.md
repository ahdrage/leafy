# JLCPCB G.4 placement status

G.4 retains every component centre, rotation, lead/copper pad and MPN from G.3. The corrected CPL is byte-identical. The U1/U2 footprint names, top mask and thermal paste change. **G.4 was uploaded and its live preview verified on 15 September 2026**, then saved as `leaf-heat-rev-g4-gerbers_Y10` / `PRIVATE-RECORD-REMOVED` with PCBA `PRIVATE-RECORD-REMOVED`. File number: `7e904afb86804cf694585ddf7d522d44`. Final stencil/process and production approvals remain required.

All six catalogue matches were checked against the current BOM, and each part was individually selected in the enlarged 3D placement viewer. L1's two terminals align; U1 has eight aligned leads and pin one upper-left; U2 is the 02U external-antenna module with eighteen aligned outer castellations, pin one upper-left and socket upper-right; U4 has six aligned leads and pin one lower-left; U5 and U6 each have fourteen aligned leads and pin one upper-left. The supplied rotations below were used without another offset. No component was moved or rotated in the viewer. The viewer does not verify concealed thermal joints or prove assembly-process acceptance.

Saved cart Product Details confirm two Economic top-side assemblies, six exact parts, manual placement confirmation, and the complete G.4 process remark. The separate PCB details confirm G.4, five four-layer boards and the complete solder-mask-defined-pad remark. Only Y10 was selected; the older groups remained unchecked. See [the G.4 cart verification](quotations/2026-09-15/cart-verification.json).

## Historical JLCPCB Rev G.3 placement check — 14 September 2026

The historical quote is `leaf-heat-rev-g3-gerbers`, PCB file number `ecc805476ca84796830c2f4ab2ec16b7`. The live viewer loaded the G.3 silkscreen and the external-antenna module. All six factory parts were inspected individually at enlarged scale. No translation or additional rotation was necessary after importing the current CPL. The viewer was checked again when restoring the same files as cart entry Y9 after cancelling a temporary unpaid Y6 checkout record; all six placements remained aligned. See [the historical G.3 cart backup](quotations/2026-09-14/cart-recheck-2026-09-14.json).

| Part | JLCPCB code | Native KiCad angle | JLC angle | Live preview check |
| --- | --- | ---: | ---: | --- |
| L1 | C2044314 | 0° | 0° | Centred, both terminals aligned, nonpolar |
| U1 | C1858393 | 0° | 270° | Eight leads aligned; pin one upper-left |
| U2 | C2926676 | 0° | 0° | External-antenna 02U model; all eighteen outer castellations aligned, pin one upper-left, socket upper-right |
| U4 | C7519 | 90° | 0° | Six leads aligned; pin one lower-left |
| U5 | C5218894 | 0° | 270° | Fourteen leads aligned; pin one upper-left |
| U6 | C2866750 | 0° | 270° | Fourteen leads aligned; pin one upper-left |

The module origin remains KiCad (73,8) mm, exported (73,92) mm with a lower-left origin. Its pin-one pad is exported (64.25,98) mm. Its different body height does not require changing this footprint anchor: the live JLCPCB model is aligned at the supplied coordinates. U2's central ground pad/paste matches the native data, but it is concealed under the 3D body; the preview is not an inspection of the solder joint.

`CPL-FACTORY-JLCPCB.csv` already includes the catalogue angle corrections. Do not rotate it again. `CPL-NATIVE-REFERENCE-ONLY.csv` and `placements-FACTORY.csv` preserve native angles; use `FACTORY-PIN1-REFERENCE.csv` to check physical pin one. For that historical G.3 check, centres and paste apertures were unchanged from G.2; G.4 changes thermal mask/paste as documented separately.

The quotation has manual production-file and component-placement approval requested, with automatic confirmation disabled in both dialogs. The assembly remark identifies the exact 02U module, excludes ANT1 from factory placement, forbids powering the incomplete assembly and requests exposed-pad DFM for U1/U2. Final assembler DFM and production placement approval remain outstanding. No hardware or vehicle test has been performed.

The old G.1 quote remains historical; its Gerbers and U2 component are obsolete. That G.3 cart entry is now superseded by G.4; do not use it for the updated mask process. The complete old G.2 design and packages are preserved under `history`.

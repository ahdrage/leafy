from pathlib import Path
import hashlib,json,zipfile,datetime
H=Path(__file__).resolve().parent;E=H/'exports';D=H/'deliverables';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((E/'independent-audit.json').read_text());m=json.loads((E/'manufacturing-audit.json').read_text())
assert a['board_sha256']==m['board_sha256']==sha(H/'leaf-heat-v7.kicad_pcb')
assert a['schematic_sha256']==sha(H/'leaf-heat-v7.kicad_sch')
g2=json.loads((E/'tenting-g4-audit.json').read_text())
assert g2['status']=='PASS' and g2['pcb_sha256']==a['board_sha256'] and g2['schematic_sha256']==a['schematic_sha256']
(D/'README.md').write_text((H/'deliverables-README.tmp').read_text())
def make(name,files,base):
 missing=[str(p) for p in files if not p.is_file()]
 assert not missing,missing
 files=sorted(set(files));manifest={'revision':'G.4','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pcb_sha256':a['board_sha256'],'schematic_sha256':a['schematic_sha256'],'files':{str(p.relative_to(base)):sha(p) for p in files}}
 if (D/name).exists():
  with zipfile.ZipFile(D/name) as z:
   prior=json.loads(z.read('PACKAGE-MANIFEST.json'))
   if all(prior.get(k)==manifest[k] for k in ['revision','pcb_sha256','schematic_sha256','files']):
    assert z.testzip() is None
    for n,h in prior['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    return  # Preserve the exact uploaded ZIP when its inputs are unchanged.
 with zipfile.ZipFile(D/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,p.relative_to(base))
  z.writestr('PACKAGE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(D/name) as z:
  assert z.testzip() is None
  for n,h in manifest['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
fabrication=list((E/'fabrication').glob('*'))
make('leaf-heat-rev-g4-gerbers.zip',fabrication,E/'fabrication')
factory=fabrication+[H/'MANUFACTURING-NOTES.md',H/'U5-G1-CHANGE.md',H/'ANTENNA-G3-CHANGE.md',H/'TENTING-G4-CHANGE.md',E/'tenting-g4-audit.json',E/'BOM-FACTORY-PCBWay.csv',E/'BOM-FACTORY-JLCPCB.csv',E/'placements-FACTORY.csv',E/'CPL-FACTORY-JLCPCB.csv',E/'assembly-map.png',E/'factory-paste.png',E/'tenting-g4-detail.png',E/'schematic.pdf',E/'manufacturing-audit.json']
make('leaf-heat-rev-g4-factory-assembly.zip',factory+[E/'FACTORY-PIN1-REFERENCE.csv',E/'CPL-NATIVE-REFERENCE-ONLY.csv',H/'JLCPCB-PLACEMENT-CHECK.md'],H)
hand=[H/x for x in ['HAND-ASSEMBLY.md','VEHICLE-WIRING.md','MOUSER-SHOPPING.md','DESIGN-REVIEW.md']]+[E/x for x in ['BOM-HAND.csv','MOUSER-TWO-BOARDS.csv','BOM-ACCESSORIES.csv','MOUSER-QUICK-ORDER-TWO-BOARDS.txt','MOUSER-CART-CHANGES.csv','MOUSER-BASKET-VERIFIED-2026-09-14.csv','MOUSER-ORIGINAL-EXPORT-2026-09-14.xls','MOUSER-CART-VERIFICATION-2026-09-14.json','assembly-map.png','back-legend.png','schematic.pdf']]
make('leaf-heat-rev-g4-hand-assembly.zip',hand+[H/'ANTENNA-G3-CHANGE.md',H/'TENTING-G4-CHANGE.md'],H)
native=[H/x for x in ['leaf-heat-v7.kicad_pcb','leaf-heat-v7.kicad_sch','leaf-heat-v7.kicad_pro','leaf-heat-v7.kicad_dru','Leaf.kicad_sym','sym-lib-table','fp-lib-table','parts.json','accessories.json','testpoints.json']]+list((H/'Leaf.pretty').glob('*.kicad_mod'))+list(H.glob('*.md'))+[E/x for x in ['independent-audit.json','manufacturing-audit.json','protection-calculations.json','erc.json','drc-final.json','BOM-FULL-REFERENCE-ONLY.csv']]
make('leaf-heat-rev-g4-kicad.zip',native+[E/'tenting-g4-audit.json',H/'apply_tenting_g4.py',H/'audit_tenting_g4.py',H/'FABRICATION-NOTES.txt'],H)
images=[E/x for x in ['top.png','ground.png','power.png','bottom.png','placement.png','factory-paste.png','assembly-map.png','back-legend.png','schematic.png','schematic.pdf','tenting-g4-detail.png']]
make('leaf-heat-rev-g4-review-images.zip',images,E)
(D/'manifest.json').write_text(json.dumps({'pcb_sha256':a['board_sha256'],'schematic_sha256':a['schematic_sha256'],'packages':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in D.glob('*.zip')}},indent=2)+'\n')
print('Five matched packages created and zip contents verified.')

# Rev G.4 manufacturing and partial assembly

Quote **five bare PCBs if required by the supplier's minimum, with only one or two assembled**. Quotation only; no order is authorized. Board: 100 × 100 mm, four copper layers, 1.6 mm nominal FR-4, 1 oz outer copper, green solder mask, white silk and lead-free finish. Retain the complete inner ground/power layers and all antenna keepouts. Keep U2’s antenna socket accessible for the customer-fitted cable; no clamps on the socket.

Use the Rev G Gerber/drill package and its matching factory BOM/CPL. **Fit exactly these six parts on top:**

| Ref | Exact manufacturer part |
| --- | --- |
| U1 | Texas Instruments LMR36510ADDAR |
| U2 | Espressif ESP32-C3-WROOM-02U-N4 — JLCPCB C2926676 |
| U4 | STMicroelectronics USBLC6-2SC6 |
| U5 | Texas Instruments TPS3760A012DYYR — JLCPCB C5218894, Catalog grade, approved Rev G.1 substitution |
| U6 | Texas Instruments TMUX1511PWR |
| L1 | Bourns SRN6045TA-220M |

No substitutions or additional placements without engineering review. U5 must be the non-latching undervoltage variant. The factory supplies these components; they are excluded from the customer's Mouser hand-parts basket. Exact catalogue IDs are supplied in the JLCPCB BOM; do not accept automatic substitutes. Quote sourcing/MOQ/attrition separately.

The top paste layer contains apertures for these six parts only. The other 49 purchased components are customer-fitted; TP1–TP7 and H1–H4 are bare PCB features. Do not populate them. Do not regenerate a stencil that includes the hand-fitted parts. The partially assembled board is not a functional circuit and must not be powered or programmed before hand assembly.

**Manufacturing process approval required:** U1/U2 use deliberate solder-mask-defined thermal pads with TOP-side mask tents over six 0.33 mm and twelve 0.30 mm unfilled plated holes respectively. Bottom hole ends remain open. Preserve the supplied top-mask artwork; DO NOT enlarge the openings, remove the caps, or override the thermal PTHs with a global via treatment. See [G.4 process drawing and dimensions](TENTING-G4-CHANGE.md) and `exports/tenting-g4-detail.png`.

The thermal paste pattern requests a **0.125 mm stencil**: U1 has two 2.71 × 1.55 mm windows separated by 0.30 mm; U2 has nine 0.60 mm squares. Confirm actual thickness, transfer/reflow process and final stencil artwork. Do not merge/enlarge the U1/U2 apertures automatically. Paste partly over U1 mask tents is intentional; the tents must remain intact. If another thickness or geometry is required, return the proposal and any cost for approval first. Inspect U1 exposed-pad attachment/voiding and U2 perimeter joints; provide inspection evidence. No finished-board functional test is implied. Keep manual PCB production-file and placement approval enabled and automatic approval disabled.

Placement origin: lower-left board corner, KiCad (0,100 mm); X right and Y up in CSV. Native-reference rotations are KiCad angles; use the separately corrected JLCPCB CPL. Review pin 1, the ESP32 connector orientation and all six placements against `assembly-map.png` and `factory-paste.png`. Keep the connector overhang and printed-case clearances intact. Quote setup, PCB batch, stencil, six parts, soldering and inspection separately. Existing Rev F quotes are obsolete for this revision.

Rev G.4 changes U1/U2 mask and paste only. It retains G.3's external-antenna module and customer plug-in ANT1 (Molex 1461530300), which is excluded from placements/paste. Fit the exact 02U module, not the older 02. Use the G.4 fabrication package, matching BOM and corrected CPL together. All G.3/G.2 quotation fabrication files are superseded.

## JLCPCB catalogue orientation

Use `exports/CPL-FACTORY-JLCPCB.csv` for JLCPCB: final rotations U1/U5/U6 = 270°, U4 = 0°, U2/L1 = 0°. These already include the catalogue zero-angle correction; do not add it again. `placements-FACTORY.csv` and `CPL-NATIVE-REFERENCE-ONLY.csv` are native KiCad references for other assemblers. Verify physical pin 1 using `FACTORY-PIN1-REFERENCE.csv` and the supplied drawings. All centres remain unchanged. See JLCPCB-PLACEMENT-CHECK.md for the current live-preview status. Final manufacturer placement approval is still required.
